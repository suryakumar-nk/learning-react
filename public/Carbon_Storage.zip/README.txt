% Installing MRST and Running the Example

This application uses the MATLAB Reservoir Simulation Toolbox, which can
be downloaded for free from http://mrst.no.

To install MRST and the reference example:

1. Download the latest version of MRST from mrst.no and unzip the download
   to a suitable folder. This will create a new folder with a name like
   "mrst-2020b", henceforth referred to as the MRST root folder. Here, 
   "2020b" refers to the version number of MRST and will change if you use
   a newer (or older) version.

2. Download the reference example: MRSTReferenceExample_CO2Storage.mlx

Once you have done this you can start MRST from within
MATLAB by running startup.m from the MRST root folder.

   run <yourpath>/<mrst-2020b>/startup.m;

This will add the basic functionality of MRST to MATLAB's search path and
display a startup message to indicate that the software is ready for use.

You can then load the demo script into your editor and run it section by
section or line by line:

   edit MRSTReferenceExample_CO2Storage.m